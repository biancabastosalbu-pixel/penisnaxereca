import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { CartDrawer } from "@/components/CartDrawer";
import { ProductCard } from "@/components/ProductCard";
import { CATEGORIES, PRODUCTS, type Category } from "@/data/products";
import { useCart } from "@/hooks/use-cart";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Bibia Linda Gacha — Vitrine de Cápsulas Kawaii" },
      {
        name: "description",
        content:
          "Cardápio digital da Bibia Linda Gacha: cápsulas, figurinhas e brindes kawaii para colecionadores. Busque, filtre por categoria e monte seu carrinho.",
      },
      { property: "og:title", content: "Bibia Linda Gacha — Vitrine de Cápsulas Kawaii" },
      {
        property: "og:description",
        content:
          "Cápsulas fofas, organizadas na vitrine. Busque, filtre e monte seu carrinho de colecionáveis kawaii.",
      },
      { property: "og:type", content: "website" },
      { property: "og:locale", content: "pt_BR" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type SortMode = "destaque" | "novidades" | "raridade";

function Index() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<Category | "todos">("todos");
  const [sort, setSort] = useState<SortMode>("destaque");
  const [cartOpen, setCartOpen] = useState(false);
  const cart = useCart();

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = PRODUCTS.filter((p) => {
      const matchesCategory = category === "todos" || p.category === category;
      const matchesQuery =
        q === "" ||
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q);
      return matchesCategory && matchesQuery;
    });
    if (sort === "novidades") {
      list = [...list].sort((a, b) => Number(b.isNew ?? false) - Number(a.isNew ?? false));
    } else if (sort === "raridade") {
      list = [...list].sort((a, b) => b.rarity - a.rarity);
    }
    return list;
  }, [query, category, sort]);

  return (
    <div className="min-h-screen bg-background font-body text-foreground">
      <header className="sticky top-0 z-40 border-b border-white/60 bg-glass backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:px-6">
          <span
            aria-hidden="true"
            className="size-9 shrink-0 rounded-full bg-gradient-to-br from-primary/70 via-white to-sky-300/70 ring-1 ring-black/5"
          />
          <div className="min-w-0 leading-none">
            <p className="truncate font-display text-lg font-bold tracking-tight">Bibia Linda</p>
            <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              vitrine de cápsulas
            </p>
          </div>
          <button
            type="button"
            onClick={() => setCartOpen(true)}
            className="ml-auto flex shrink-0 items-center gap-2 rounded-full bg-foreground px-3 py-2 text-sm font-medium text-background transition-transform [transition-timing-function:var(--ease-vitrine)] hover:-translate-y-0.5"
            aria-label={`Abrir carrinho, ${cart.totalItems} itens`}
          >
            <span aria-hidden="true" className="size-2 rounded-full bg-primary" />
            Carrinho
            <span className="rounded-full bg-primary px-1.5 font-mono text-xs text-primary-foreground">
              {cart.totalItems}
            </span>
          </button>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-b from-sky-200/70 via-white/0 to-primary/10"
        />
        <div aria-hidden="true" className="absolute -right-10 -top-10 size-40 rounded-full bg-primary/25 blur-3xl" />
        <div aria-hidden="true" className="absolute -left-10 top-20 size-32 rounded-full bg-sky-300/30 blur-3xl" />
        <div className="relative mx-auto max-w-6xl px-4 pb-6 pt-10 sm:px-6">
          <div className="max-w-[30ch] animate-rise text-balance">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-primary">
              kawaii premium · gashapon
            </p>
            <h1 className="mt-2 font-display text-5xl font-bold tracking-tight sm:text-6xl">
              Cápsulas <em className="italic">fofas</em>, organizadas na vitrine.
            </h1>
            <p className="mt-3 max-w-[42ch] text-pretty text-muted-foreground">
              Uma loja de gashapon para colecionadores. Abra a cápsula, guarde a figurinha,
              complete a coleção.
            </p>
          </div>

          <div className="mt-6 flex flex-col gap-2 sm:flex-row sm:items-center">
            <label className="flex flex-1 items-center gap-2 rounded-full bg-white/60 px-4 py-2.5 ring-1 ring-black/5 backdrop-blur-md focus-within:ring-2 focus-within:ring-ring">
              <span aria-hidden="true" className="text-muted-foreground">⌕</span>
              <input
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Buscar cápsula, figurinha, brinde…"
                aria-label="Buscar no cardápio"
                className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              />
            </label>
            <div className="flex gap-2 sm:ml-auto" role="group" aria-label="Ordenar produtos">
              {(
                [
                  ["destaque", "Destaque"],
                  ["novidades", "Novidades"],
                  ["raridade", "Raridade ✦"],
                ] as [SortMode, string][]
              ).map(([mode, label]) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => setSort(mode)}
                  aria-pressed={sort === mode}
                  className={
                    sort === mode
                      ? "rounded-full bg-foreground px-3 py-2 text-sm font-medium text-background ring-1 ring-black/5"
                      : "rounded-full bg-white/60 px-3 py-2 text-sm ring-1 ring-black/5 backdrop-blur-md transition-colors hover:bg-white"
                  }
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <nav aria-label="Filtrar por categoria" className="mt-4 flex gap-2 overflow-x-auto pb-1">
            {CATEGORIES.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setCategory(c.id)}
                aria-pressed={category === c.id}
                className={
                  category === c.id
                      ? "shrink-0 rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground ring-1 ring-black/5"
                      : "shrink-0 rounded-full bg-white/60 px-4 py-2 text-sm font-medium text-muted-foreground ring-1 ring-black/5 backdrop-blur-md transition-colors hover:text-foreground"
                }
              >
                {c.label}
              </button>
            ))}
          </nav>
        </div>
      </section>

      <main className="mx-auto max-w-6xl px-4 pb-16 sm:px-6">
        <section aria-label="Produtos" className="animate-rise [animation-delay:120ms]">
          <h2 className="font-display text-2xl font-bold tracking-tight">
            {category === "todos"
              ? "Cápsulas em destaque"
              : CATEGORIES.find((c) => c.id === category)?.label}
          </h2>
          {visible.length === 0 ? (
            <p className="mt-6 rounded-2xl bg-glass p-8 text-center text-sm text-muted-foreground ring-1 ring-black/5 backdrop-blur-xl">
              Nenhum item encontrado para “{query}”. Tente outro termo ou categoria.
            </p>
          ) : (
            <div className="mt-4 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3">
              {visible.map((product) => (
                <ProductCard key={product.id} product={product} onAdd={cart.add} />
              ))}
            </div>
          )}
        </section>
      </main>

      <footer className="border-t border-white/60 bg-glass backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-6 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <p className="font-display text-base font-bold tracking-tight text-foreground">
            Bibia Linda
          </p>
          <p className="font-mono text-xs">
            © 2026 · vitrine sem pedidos · apenas para colecionar
          </p>
        </div>
      </footer>

      <CartDrawer
        open={cartOpen}
        items={cart.cartItems}
        subtotal={cart.subtotal}
        totalItems={cart.totalItems}
        onClose={() => setCartOpen(false)}
        onAdd={cart.add}
        onRemove={cart.remove}
        onClear={cart.clear}
      />
    </div>
  );
}
