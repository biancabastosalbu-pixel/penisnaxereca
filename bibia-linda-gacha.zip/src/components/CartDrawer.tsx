import { useEffect } from "react";
import { formatPrice } from "@/data/products";
import type { CartItem } from "@/hooks/use-cart";

interface CartDrawerProps {
  open: boolean;
  items: CartItem[];
  subtotal: number;
  totalItems: number;
  onClose: () => void;
  onAdd: (id: string) => void;
  onRemove: (id: string) => void;
  onClear: () => void;
}

export function CartDrawer({
  open,
  items,
  subtotal,
  totalItems,
  onClose,
  onAdd,
  onRemove,
  onClear,
}: CartDrawerProps) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label="Carrinho">
      <button
        type="button"
        aria-label="Fechar carrinho"
        onClick={onClose}
        className="absolute inset-0 animate-fade-in bg-foreground/30 backdrop-blur-sm"
      />
      <aside className="absolute right-0 top-0 flex h-full w-full max-w-md animate-slide-in flex-col bg-glass shadow-2xl backdrop-blur-xl">
        <div className="flex items-center justify-between border-b border-black/5 p-4 sm:p-6">
          <div>
            <h2 className="font-display text-2xl font-bold tracking-tight">Seu carrinho</h2>
            <p className="text-sm text-muted-foreground">Cápsulas guardadas na vitrine</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar"
            className="grid size-9 place-items-center rounded-full bg-white/60 text-lg ring-1 ring-black/5 transition-colors hover:bg-white"
          >
            ×
          </button>
        </div>

        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-2 p-8 text-center">
            <span className="text-4xl" aria-hidden="true">◌</span>
            <p className="font-display text-lg font-bold">Carrinho vazio</p>
            <p className="text-sm text-muted-foreground">
              Escolha uma cápsula na vitrine para começar sua coleção.
            </p>
          </div>
        ) : (
          <>
            <ul className="flex-1 divide-y divide-black/5 overflow-y-auto">
              {items.map(({ product, quantity }) => (
                <li key={product.id} className="flex items-center gap-3 p-3 sm:p-4">
                  <img
                    src={product.image}
                    alt=""
                    loading="lazy"
                    width={64}
                    height={64}
                    className="size-16 shrink-0 rounded-xl object-cover outline-1 -outline-offset-1 outline-black/5"
                  />
                  <div className="min-w-0 flex-1">
                    <h3 className="truncate font-display font-bold tracking-tight">
                      {product.name}
                    </h3>
                    <p className="font-mono text-xs text-muted-foreground">
                      {formatPrice(product.price)} · cada
                    </p>
                  </div>
                  <div className="flex items-center gap-2 rounded-full bg-white/60 p-1 ring-1 ring-black/5">
                    <button
                      type="button"
                      onClick={() => onRemove(product.id)}
                      aria-label={`Diminuir quantidade de ${product.name}`}
                      className="grid size-7 place-items-center rounded-full text-muted-foreground transition-colors hover:text-foreground"
                    >
                      −
                    </button>
                    <span className="w-4 text-center font-mono text-sm" aria-live="polite">
                      {quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => onAdd(product.id)}
                      aria-label={`Aumentar quantidade de ${product.name}`}
                      className="grid size-7 place-items-center rounded-full bg-primary text-primary-foreground"
                    >
                      +
                    </button>
                  </div>
                  <span className="w-16 shrink-0 text-right font-mono text-sm font-medium">
                    {formatPrice(product.price * quantity)}
                  </span>
                </li>
              ))}
            </ul>

            <div className="border-t border-black/5 bg-white/40 p-4 sm:p-6">
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs uppercase tracking-[0.15em] text-muted-foreground">
                  Subtotal · {totalItems} {totalItems === 1 ? "item" : "itens"}
                </span>
                <span className="font-mono text-sm">{formatPrice(subtotal)}</span>
              </div>
              <div className="mt-2 flex items-center justify-between">
                <span className="font-display text-lg font-bold">Total</span>
                <span className="font-display text-2xl font-bold tracking-tight">
                  {formatPrice(subtotal)}
                </span>
              </div>
              <button
                type="button"
                onClick={onClear}
                className="mt-4 w-full rounded-full bg-foreground px-4 py-3 text-sm font-medium text-background transition-transform [transition-timing-function:var(--ease-vitrine)] hover:-translate-y-0.5 active:translate-y-0"
              >
                Limpar carrinho
              </button>
              <p className="mt-3 text-center font-mono text-[11px] text-muted-foreground">
                Vitrine sem pedidos · apenas para colecionar
              </p>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}
