import { formatPrice, type Product } from "@/data/products";

interface ProductCardProps {
  product: Product;
  onAdd: (id: string) => void;
}

function rarityLabel(rarity: number): string {
  return "✦".repeat(rarity);
}

export function ProductCard({ product, onAdd }: ProductCardProps) {
  return (
    <article className="overflow-hidden rounded-2xl bg-glass ring-1 ring-black/5 backdrop-blur-xl transition-[transform,box-shadow] duration-300 [transition-timing-function:var(--ease-vitrine)] hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/10">
      <div className="relative aspect-square w-full overflow-hidden bg-gradient-to-br from-primary/10 to-sky-200/40">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          width={816}
          height={816}
          className="size-full object-cover"
        />
        {product.isNew && (
          <span className="absolute left-3 top-3 rounded-full bg-foreground px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.15em] text-background">
            Novo
          </span>
        )}
      </div>
      <div className="p-3 sm:p-4">
        <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-primary">
          raridade {rarityLabel(product.rarity)}
        </p>
        <h3 className="mt-1 text-balance font-display text-lg font-bold tracking-tight">
          {product.name}
        </h3>
        <p className="mt-1 text-pretty text-sm text-muted-foreground">
          {product.description}
        </p>
        <div className="mt-3 flex items-center justify-between gap-2">
          <span className="font-mono text-sm font-medium">
            {formatPrice(product.price)}
          </span>
          <button
            type="button"
            onClick={() => onAdd(product.id)}
            aria-label={`Adicionar ${product.name} ao carrinho`}
            className="rounded-full bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground transition-colors duration-200 [transition-timing-function:var(--ease-vitrine)] hover:bg-foreground focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
          >
            Adicionar
          </button>
        </div>
      </div>
    </article>
  );
}
