import { useCallback, useMemo, useState } from "react";
import { PRODUCTS, type Product } from "@/data/products";

export interface CartItem {
  product: Product;
  quantity: number;
}

export function useCart() {
  const [items, setItems] = useState<Record<string, number>>({});

  const add = useCallback((id: string) => {
    setItems((prev) => ({ ...prev, [id]: (prev[id] ?? 0) + 1 }));
  }, []);

  const remove = useCallback((id: string) => {
    setItems((prev) => {
      const next = { ...prev };
      const qty = (next[id] ?? 0) - 1;
      if (qty <= 0) delete next[id];
      else next[id] = qty;
      return next;
    });
  }, []);

  const clear = useCallback(() => setItems({}), []);

  const cartItems = useMemo<CartItem[]>(
    () =>
      Object.entries(items)
        .map(([id, quantity]) => {
          const product = PRODUCTS.find((p) => p.id === id);
          return product ? { product, quantity } : null;
        })
        .filter((i): i is CartItem => i !== null),
    [items],
  );

  const totalItems = useMemo(
    () => cartItems.reduce((sum, i) => sum + i.quantity, 0),
    [cartItems],
  );

  const subtotal = useMemo(
    () => cartItems.reduce((sum, i) => sum + i.product.price * i.quantity, 0),
    [cartItems],
  );

  return { cartItems, totalItems, subtotal, add, remove, clear };
}
