import gatinhoNuvem from "@/assets/products/gatinho-nuvem.jpg";
import milkyBerry from "@/assets/products/milky-berry.jpg";
import ursinhoPo from "@/assets/products/ursinho-po.jpg";
import raposaSakura from "@/assets/products/raposa-sakura.jpg";
import pinguimMatcha from "@/assets/products/pinguim-matcha.jpg";
import chaveiroLua from "@/assets/products/chaveiro-lua.jpg";
import adesivosHolo from "@/assets/products/adesivos-holo.jpg";
import coelhoTaro from "@/assets/products/coelho-taro.jpg";
import estrelaMar from "@/assets/products/estrela-mar.jpg";

export type Category = "capsulas" | "figurinhas" | "brindes";

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: Category;
  rarity: 1 | 2 | 3;
  image: string;
  isNew?: boolean;
}

export const CATEGORIES: { id: Category | "todos"; label: string }[] = [
  { id: "todos", label: "Todos" },
  { id: "capsulas", label: "Cápsulas" },
  { id: "figurinhas", label: "Figurinhas" },
  { id: "brindes", label: "Brindes" },
];

export const PRODUCTS: Product[] = [
  {
    id: "gatinho-nuvem",
    name: "Gatinho Nuvem",
    description: "Cápsula transparente com miniatura em resina fosca e base pastel.",
    price: 24.9,
    category: "capsulas",
    rarity: 3,
    image: gatinhoNuvem,
    isNew: true,
  },
  {
    id: "milky-berry",
    name: "Milky Berry",
    description: "Charm de milkshake em resina translúcida com glitter holográfico.",
    price: 18.5,
    category: "capsulas",
    rarity: 2,
    image: milkyBerry,
  },
  {
    id: "ursinho-po",
    name: "Ursinho Pó",
    description: "Miniatura aveludada em tom creme com acabamento acetinado.",
    price: 12.9,
    category: "figurinhas",
    rarity: 1,
    image: ursinhoPo,
  },
  {
    id: "raposa-sakura",
    name: "Raposa Sakura",
    description: "Raposinha de resina com pétalas pintadas à mão e brilho nacarado.",
    price: 32.9,
    category: "figurinhas",
    rarity: 3,
    image: raposaSakura,
    isNew: true,
  },
  {
    id: "pinguim-matcha",
    name: "Pinguim Matcha",
    description: "Cápsula verde pastel com pinguim segurando um copinho de matcha.",
    price: 21.9,
    category: "capsulas",
    rarity: 2,
    image: pinguimMatcha,
  },
  {
    id: "chaveiro-lua",
    name: "Chaveiro Lua Minguante",
    description: "Chaveiro de acrílico espelhado com corrente dourada e estrelinha.",
    price: 14.9,
    category: "brindes",
    rarity: 1,
    image: chaveiroLua,
  },
  {
    id: "adesivos-holo",
    name: "Pack Adesivos Holo",
    description: "Seis adesivos holográficos à prova d'água com personagens da coleção.",
    price: 9.9,
    category: "brindes",
    rarity: 1,
    image: adesivosHolo,
  },
  {
    id: "coelho-taro",
    name: "Coelho Taro",
    description: "Figurinha lilás aveludada com laço de cetim e olhinhos bordados.",
    price: 27.9,
    category: "figurinhas",
    rarity: 2,
    image: coelhoTaro,
    isNew: true,
  },
  {
    id: "estrela-mar",
    name: "Estrela do Mar Soda",
    description: "Cápsula azul-gelo com estrela translúcida e bolhinhas de soda.",
    price: 19.9,
    category: "capsulas",
    rarity: 2,
    image: estrelaMar,
  },
];

export function formatPrice(value: number): string {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}
